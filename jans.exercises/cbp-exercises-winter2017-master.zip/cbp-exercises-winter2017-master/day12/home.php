<?php
    require_once 'functions.php';
    render_page('home-content.php');
?>