<footer>
    &copy; <?php print_current_year(); ?> Me & myself
</footer>